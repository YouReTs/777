﻿using System;
using tessnet2;
using System.Drawing;
//using System.Drawing.Drawing2D;
//using System.Drawing.Imaging;


namespace ConsoleApp1
{

    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            var image = new Bitmap(@"1.bmp");
            // now add the following C# line in the code page  

            var ocr = new Tesseract();
            ocr.Init(@"tessdata\", "rus", false);
            var result = ocr.DoOCR(image, Rectangle.Empty);
            foreach (tessnet2.Word word in result)
            {
                Console.WriteLine(word.Text);
            }


        }
    }
}
